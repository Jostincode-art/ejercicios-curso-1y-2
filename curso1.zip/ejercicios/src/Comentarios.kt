// tipo de comentario
/*
* hola
* desarrollador
* eres grande
* */